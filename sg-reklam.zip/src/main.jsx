
import React from 'react'
import ReactDOM from 'react-dom/client'
import SGReklamApp from './SGReklamApp.jsx'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <SGReklamApp />
  </React.StrictMode>
)
